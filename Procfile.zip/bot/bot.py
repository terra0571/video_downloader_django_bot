import os
from dotenv import load_dotenv
from pyrogram import Client, filters
from video_app.downloader import download_video

# .env fayldan o'zgaruvchilarni yuklaymiz
load_dotenv()

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")

# Pyrogram botni ishga tushuramiz
app = Client("video_downloader_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

@app.on_message(filters.command("start"))
async def start(client, message):
    await message.reply("🎬 Salom! Video havolasini yuboring, men sizga uni yuklab beraman.")

@app.on_message(filters.text)
async def handle_link(client, message):
    url = message.text.strip()
    try:
        file_path, title = download_video(url)
        await message.reply_video(file_path, caption=title)
        os.remove(file_path)
    except Exception as e:
        await message.reply(f"❌ Xatolik: {e}")

# Botni ishga tushiramiz
app.run()
